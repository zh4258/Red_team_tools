# KeyLogger

A simple Windows keylogger written in Python

## Installation

1. install pynput on the target machine
2. Download KeyLoggerTarget.py on the target machine
   1. Replace parts of code that need to be replaced (taylor the code to the specific host machine)
3. Download KeyLoggerHost.py on the host machine
   1. Replace parts of code that need to be replaced (taylor the code to the specific target machine)
