# WindowsUpdate

Tools designed to be used by just running the "Gray - Do not touch" file as it will run all scripts and place it to startup
