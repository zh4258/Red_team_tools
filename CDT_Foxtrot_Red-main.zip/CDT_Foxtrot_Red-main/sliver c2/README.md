ok so

only run sliverDeploy.sh on your kali vm, this will install both the server and the client files to your machine<br />

we can all run on the same server with a little bit of setup, need to implement multiplayer mode, create operators and drop user files in the right spot on everyone's machines

ig we could also just run separately, we can figure that out tho 

https://github.com/BishopFox/sliver - sliver git repo, also has documentation somewhere in the readme<br />
https://github.com/BishopFox/sliver/wiki/Getting-Started - for ease of access, this is a good starting point for sliver<br />
https://dominicbreuker.com/post/learning_sliver_c2_01_installation/ - this kind of helped me understand the installation, has some other documentation type links in there also<br />
https://redsiege.com/blog/2022/11/introduction-to-sliver/ - also really helpful for understanding how sliver works<br />
https://vk9-sec.com/how-to-set-up-use-c2-sliver/ - user friendly guide for commands <br />

