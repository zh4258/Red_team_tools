# CET_Foxtrot_Red

A collection of self made Red Team tools
